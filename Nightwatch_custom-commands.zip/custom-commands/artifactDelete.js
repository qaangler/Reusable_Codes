//this command is for Delete the Artifact of all type 
exports.command = function ( artifactType, excelColumn, xlName, sheetName, xlRow, xlColumn, failureReasonColumn ) {
  //Access the variable globally defined
  var excel = this.globals.excelCol;
  excel.AG.length = 0;
  var ignoreCase = require ( 'ignore-case' );
  this.useXpath ( ).
  //Wait and click the All contents to Edit the Articles 
  waitForElementVisible ( "//span[contains(@class,'left-sidebar-text ng-binding portal expand')][text()='all content']", 6000, false, function ( allContent ) {
    if ( allContent.value == true ) {
      this.click ( "//span[contains(@class,'left-sidebar-text ng-binding portal expand')][text()='all content']" ).
      //Get the Artifact count before deleting Artifacts
      waitForElementVisible ( '//span[@class="artifact-count-text ng-binding"]', 5000, false, function ( artifactCount ) {
        if ( artifactCount.value == true ) {
          this.getText ( '//span[@class="artifact-count-text ng-binding"]', function ( preCount ) {
            //Extract the Artifact count alone from the fetched artifact text & numbers
            var artifactpreCount = preCount.value.substr ( 0, preCount.value.lastIndexOf ( 'A' ) - 1 );
            console.log ( "artifactpreCount", artifactpreCount );
            this.click ( '//input[@id="search_input"]' ).
            //Search the Artifacts to delete
            waitForElementVisible ( '//input[@placeholder="Search by Name"]', 5000, false, function ( searchIcon ) {
              if ( searchIcon.value == true ) {
                //set the keyword to the search Artifact field
                this.clearValue ( '//input[@placeholder="Search by Name"]' ).
                setValue ( '//input[@placeholder="Search by Name"]', excel.D[ excelColumn ] ).
                keys ( this.Keys.ENTER ).
                keys ( this.Keys.ENTER ).
                waitForElementVisible ( '//span/a[contains(@class,"name-container" )]/span[@id="' + excel.D[ excelColumn ] + '"]', 5000, false, function ( searchArtifact ) {
                  if ( searchArtifact.value == true ) {
                    this.getAttribute ( '//span/a[contains(@class,"name-container" )]/span[@id="' + excel.D[ excelColumn ] + '"]/ancestor::item-cell', "index", function ( searchArtifactIndex ) {
                      //get the count of search result
                      this.elements ( 'xpath', '//span/a[contains(@class,"name-container" )]/span[@id="' + excel.D[ excelColumn ] + '"]', function ( searchCount ) {
                        for ( let indexValue = parseInt ( searchArtifactIndex.value ) + 1; indexValue <= searchCount.value.length; indexValue++ ) {
                          this.waitForElementPresent ( "//i[contains(@class,'index-header-icon listview-icon' )]", 5000, false, function ( ) {
                            if ( excel.AG.indexOf ( 'FAIL' ) == -1 ) {
                              this.click ( "//i[contains(@class,'index-header-icon listview-icon')]" ).
                              pause ( 5000 ).
                              //Search for the Artifact with Category
                              getText ( '//item-cell[' + indexValue + ']/*//span/a[contains(@class,"name-container" )]/span[@id="' + excel.D[ excelColumn ] + '"]/following::span[1]', function ( categoryType ) {
                                if ( categoryType.value == artifactType ) {
                                  this.waitForElementPresent ( '//item-cell[' + indexValue + ']/*//span/a[contains(@class,"name-container" )]/span[@id="' + excel.D[ excelColumn ] + '"]', 5000, false, function ( ) {
                                    //Delete the artifact in the list view
                                    if ( excel.B[ excelColumn ] == 'LIST' ) {
                                      this.
                                      getLocationInView ( '//item-cell[' + indexValue + ']/*//span/span[@class="options-container"]/toggle-menu/span' ).
                                      click ( '//item-cell[' + indexValue + ']/*//span/span[@class="options-container"]/toggle-menu/span' ).
                                      click ( '//item-cell[' + indexValue + ']/*//span/span[@class="options-container"]//*/ng-transclude' ).
                                      click ( '//item-cell[' + indexValue + ']/div//span[@ng-click="destroyArtifact( item )"]' );
                                    }
                                    else if ( excel.B[ excelColumn ] == 'GRID' ) {
                                      //Delete the artifact in the Grid view
                                      this.click ( "//i[contains(@class,'index-header-icon gridview-icon' )]" ).
                                      pause ( 3000 ).
                                      getLocationInView ( '//item-cell[' + indexValue + ']/*//span[@class="options-container"]/toggle-menu/span' ).
                                      click ( '//item-cell[' + indexValue + ']/*//span[@class="options-container"]/toggle-menu/span' ).
                                      click ( '//item-cell[' + indexValue + ']/*//span[@class="options-container"]//*/ng-transclude' ).
                                      click ( '//item-cell[' + indexValue + ']/div//span[@ng-click="destroyArtifact( item )"]' );
                                    }
                                    else {
                                      //Delete the artifact with the Edit opion
                                      this.pause ( 3000 ).
                                      getLocationInView ( '//item-cell[' + indexValue + ']/*//span/a[contains(@class,"name-container" )]/span[@id="' + excel.D[ excelColumn ] + '"]' ).
                                      click ( '//item-cell[' + indexValue + ']/*//span/a[contains(@class,"name-container" )]/span[@id="' + excel.D[ excelColumn ] + '"]' ).
                                      pause ( 3000 ).
                                      click ( "//div[@class='show-header-wrapper ng-scope']/*//i[@class='trashcan-icon hover-icon delete-artifact ng-scope']" ).
                                      pause ( 3000 ).
                                      click ( '//ng-view[@class="ng-scope"]/div//span[@ng-click="destroyArtifact( artifact )"]' );
                                    }
                                    this.pause ( 5000 ).
                                    click ( "//span[contains(@class,'left-sidebar-text ng-binding portal expand')][text()='all content']" ).
                                    pause ( 5000 ).
                                    waitForElementVisible ( '//span[@class="artifact-count-text ng-binding"]', 5000, false, function ( artifctCount ) {
                                      if ( artifctCount.value == true ) { 
                                        //Check the count of Artifacts decreased 
                                        this.getText ( '//span[@class="artifact-count-text ng-binding"]', function ( postCount ) {
                                          var artifactpostCount = postCount.value.substr ( 0, postCount.value.lastIndexOf ( 'A' ) - 1 );
                                          var artifactpostCounts = parseInt ( artifactpostCount ) + 1;
                                          console.log ( "artifactpostCount", artifactpostCounts );
                                          //Compare the Artifact count & confirm its deleted successfully
                                          if ( artifactpreCount == artifactpostCounts ) {
                                            excel.AG.push ( 'FAIL' );                                            
                                            this.writeToExcelPass ( xlName, sheetName, xlRow, xlColumn );
                                          }
                                          else {
                                            excel.AG.push ( 'FAIL' );
                                            //write the status as Fail to delete the Articles in excel
                                            this.verify.fail ( artifactpostCounts, artifactpreCount, 'Fail to delete the Artifacts' );
                                            this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + artifactpostCounts + "'. ExpectedResult: '" + artifactpreCount + "'(Fail to delete the Artifacts)" );
                                          }
                                        } );
                                      }
                                      else {
                                        excel.AG.push ( 'FAIL' );
                                        //write  the status as Fail to redirect to the All content page once deleted the Articles in excel
                                        this.verify.fail ( artifctCount.value, true, 'Fail to redirect to the All content page once deleted the Articles' );
                                        this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + artifctCount.value + ". ExpectedResult: 'true'(Fail to redirect to the All content page once deleted the Articles )" );
                                      }
                                    } )
                                  } );
                                }
                                else if ( indexValue == searchCount.value.length ) {
                                  //write to fail status as Searched Artifact for Article category is not present in the list
                                  this.verify.fail ( categoryType.value, 'Article', 'Searched Artifact for Article category is not present in the list' );
                                  this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + categoryType.value + ". ExpectedResult: 'Article'(Searched Artifact for Article category is not present in the list)" );
                                }
                              } );
                            }
                          } );
                        }
                      } );
                    } );
                  }
                  else {
                    //write to fail status as searched Artifact is not Present
                    this.verify.fail ( searchArtifact.value, 'true', 'Searched Artifact is not present in the list' );
                    this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + searchArtifact.value + ". ExpectedResult: 'true'(Searched Artifact is not present in the list)" );
                  }
                } );
              }
              else {
                //write to fail status as Search textbox is not visible after clicking All contents
                this.verify.fail ( searchIcon.value, true, 'Search textbox is not visible after clicking All contents' );
                this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + searchIcon.value + ". ExpectedResult: 'true'(Search textbox is not visible after clicking All contents)" );
              }
            } );
          } );
        }
        else {
          //write to fail status as Fail to display the Artifact count in all contents
          this.verify.fail ( artifactCount.value, true, 'Fail to display the Artifact count in all contents' );
          this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + artifactCount.value + ". ExpectedResult: 'true'(Fail to display the Artifact count in all contents)" );
        }
      } );
    }
    else {
      //write to fail status as All content side bar element is not visible
      this.verify.fail ( allContent.value, true, 'All content side bar element is not visible' );
      this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + allContent.value + ". ExpectedResult: 'true'(All content side bar element is not visible)" );
    }
  } );
  return this;
};