//this function is for searchign the Portal Campaign
exports.command = function ( sheetName, campaignstate, excelRow ) {
  this.useXpath ( ).
  //wait for the Campaigns menu to visible
  waitForElementVisible ( "//li/a[contains(.,'Campaigns')]", 3000, false, function ( campaigns ) {
    if ( campaigns.value == true ) {
      this.click ( "//li/a[contains(.,'Campaigns')]" );
      if ( campaignstate == "TURN ON" || campaignstate == "Active" ) {
        this.pause ( 5000 ).
        verify.visible ( "//li/a[contains(.,'Active')]" ).
        click ( "//li/a[contains(.,'Active')]" ).
        pause ( 5000 );
      }
      else {
        this.pause ( 5000 ).useXpath ( ).
        verify.visible ( "//li/a[contains(.,'Inactive')]" ).
        click ( "//li/a[contains(.,'Inactive')]" ).
        pause ( 5000 );
      }
    }
    else {
      //write to fail status as no results found while search the content title
      this.verify.fail ( campaigns.value, true,
        'Timeout loading issue in clicking the Campaigns menu in Content' );
      this.writeToExcelFail ( 'boxxspring.xlsx', '"' + sheetName + '"', ++excelRow, 9, 10,
        "ActualResult: '" + campaigns.value +
        ". ExpectedResult: 'true' ( Timeout loading issue in clicking the Campaigns menu in Content" );
    }
  } );
  return this;
};