//this function is for check and add properties in Video URL
var Excel = require ( 'exceljs' );
var workbook1 = new Excel.Workbook ( );
if  ( typeof require !== 'undefined' )  XLSX = require ( 'xlsx' );
var result = [];
exports.command = function ( videoTitle , shortTitle , shortDesc , author , attribution , categoryName , shortNote , dragImg , currentCount )  {
  this.pause ( 5000 ).
  click ( ".edit-form > div >.btn-primary" ).
  pause ( 5000 ).
  //Edit the title
  waitForElementVisible ( '.container-head > text-field > input' , 5000 , false ) 
  console.log ( currentCount );
  this.pause ( 5000 ).
  //Verify the Video title field is visbile
  verify.visible ( ".container-head > text-field > input" ).
  //Clear the Video title data in field
  clearValue ( '.container-head > text-field > input' ).
  //Enter the Video title data in field
  setValue ( '.container-head > text-field > input' , videoTitle ).
  //Check video player
  waitForElementVisible ( '.player-container >.preview-embed' , 5000 , false ).
  pause(5000).
  //Verify the Preview embed field is visbile
  verify.visible ( ".player-container >.preview-embed" ).
  //Check the title display is visible
  verify.visible ( ".edit-form > section >.input-headline-min" ).
  //Check the description display is visible
  verify.visible ( ".edit-form > section >.input-description-min" ).
  //Verify the properties tab is visible
  verify.visible ( ".video-tabs > a[ href='#properties']" ).
  pause(3000).
  //Click the properties tab
  click ( ".video-tabs > a[ href='#properties']" ).
  pause ( 5000 ).
  //Check and enter short name
  verify.visible ( "textarea[ ng-model='artifact.shortName']" ).
  //Clear the Short Name data in field
  clearValue ( "textarea[ ng-model='artifact.shortName']" ).
  //Enter the Short Name data in field
  setValue ( "textarea[ ng-model='artifact.shortName']", shortTitle ).
  //Check and enter short description
  verify.visible ( "textarea[ ng-model='artifact.shortDescription']" ).
  //Clear the Short description data in field
  clearValue ( "textarea[ ng-model='artifact.shortDescription']" ).
  //Enter the Short description data in field
  setValue ( "textarea[ ng-model='artifact.shortDescription']", shortDesc ).
  pause ( 5000 ).
  //Check the Authors field is visible
  verify.visible ( ".attribution-container>a[ng-click='showAddAuthor()']" ).
  //Click on the Authors dropdown
  click ( ".attribution-container>a[ng-click='showAddAuthor()']" ).
  pause ( 5000 ).
  //Enter the author name in the search field
  setValue ( ".search-form" , author.trim() ).
  pause ( 5000 ).
  useXpath ( ).
  //Click on the Authors dropdown option
  click ( "//ul/li/a/span[ text ( ) = '" + author.trim() + "']" ).
  pause ( 5000 ).
  useCss ( ).
  //Select Attribution
  getValue ( ".add-icon > i:nth-child( 1 ) " , function ( attributeValue )  {
    var attributeValueset = attributeValue.value;
    console.log ( "attribute value" + attributeValueset ) 
    if  ( attributeValueset === null )  {
      this.
      //Check the attribution field is visible
      verify.visible ( ".attribution-container>a[ng-click='showAddAttribution()']" ).
      //Click on the attribution dropdown option
      click ( ".attribution-container>a[ng-click='showAddAttribution()']" ).
      pause ( 5000 ).
      //Enter the attribution name in the search field
      setValue ( ".search-form" , attribution.trim() ).
      pause ( 5000 ).
      useXpath ( ).
      //Click on the attribution dropdown option
      click ( "//ul/li/a/span[ text( ) = '" + attribution.trim( ) +"']" ).
      pause ( 5000 ).
      useCss ( ) 
    }
    else {
      console.log ( "Attribution is already Exists" );
      workbook1.xlsx.readFile ( 'boxxspring.xlsx' , {
          cellStyles: true
        } ) 
       .then ( function ( )  {
          var worksheet1 = workbook1.getWorksheet ( 'VideourlEdit' );
          var row = worksheet1.getRow ( excelColumnn );
          row.getCell ( 14 ).font = {
            bold: true,
            color: {
              argb: '1B29F3'
            }
          };
          row.alignment = {
            wrapText: true
          }
          row.getCell ( 14 ).value = "Attribution is already Exists";
          result.push ( 'PASS' );
          for  ( var col = 1; col < 50; col++ )  {
            worksheet1.getColumn ( col ).hidden = false;
            for  ( var rows = 1; rows < 50; rows++ )  {
              worksheet1.getRow ( rows ).hidden = false;
            }
          }
          workbook1.xlsx.writeFile ( 'boxxspring.xlsx' );
          row.commit ( );
        } );
    }
    //Check categories
    this.waitForElementVisible ( '.collections-widget', 10000 ).
    verify.visible ( ".collections-widget" ).
    pause ( 5000 ).
    clearValue ( ".collections-widget > input" ).
    setValue ( ".collections-widget > input", categoryName ).
    pause ( 5000 ).    
    verify.visible ( ".suggestion-list-wrap > div:nth-child( 1 )  > div:nth-child( 1 ) " ).
    click ( ".suggestion-list-wrap > div:nth-child( 1 )  > div:nth-child( 1 ) " ).
    getText ( ".ng-binding.ng-scope", function ( validateErrMsg )  {
      var validateErrMsg = validateErrMsg.value;
      console.log ( "Validation Message: " + validateErrMsg ) 
    } );
    //Check and add note
    this.verify.visible ( "textarea[ ng-model='artifact.note']" ).
    clearValue ( "textarea[ ng-model='artifact.note']" ).
    setValue ( "textarea[ ng-model='artifact.note']" , shortNote ).
    pause ( 5000 )   
  } );
  //Check and click save button
  this.verify.visible ( ".btn-active" ).
  click ( ".btn-active" ).
  pause ( 5000 ).
  //Search for videos link
  useXpath ( ).
  //Verify the Videos menu in CONTENT is visible
  verify.containsText ( "//ul/li/a[ text ( ) = 'Videos']" , "Videos" ).
  pause ( 5000 ).
  //Click on the Videos menu in CONTENT is visible
  click ( "//ul/li/a[ text ( ) = 'Videos']" ).
  useCss ( ).
  pause ( 5000 ) 
  return this;
};